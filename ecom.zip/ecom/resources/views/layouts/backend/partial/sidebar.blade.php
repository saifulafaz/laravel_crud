<div class="sidebar-scrollbar">

              <!-- sidebar menu -->
              <ul class="nav sidebar-inner" id="sidebar-menu">
                

                
                  <li  class="has-sub active expand" >
                    <a class="sidenav-item-link" href="{{url('admin')}}">
                      <i class="mdi mdi-view-dashboard-outline"></i>
                      <span class="nav-text">Dashboard</span> <b class="caret"></b>
                    </a>
                   
                  </li>
          <li  class="has-sub" >
                    <a class="sidenav-item-link" href="{{ url('category') }}">
                      <i class="mdi mdi-buffer"></i>
                      <span class="nav-text">Category</span> 
                    </a>
                  </li>
          <li  class="has-sub" >
                    <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse" data-target="#charts"
                      aria-expanded="false" aria-controls="charts">
                      <i class="mdi mdi-alpha-p-box"></i>
                      <span class="nav-text">Add Product</span> 
                    </a>
                  </li>
              </ul>

            </div>