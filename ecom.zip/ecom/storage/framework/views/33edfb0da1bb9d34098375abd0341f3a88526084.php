<?php $__env->startSection('content'); ?>
<div class="content">							
  <div class="row">
		<div class="col-lg-10">
					<div class="card-header card-header-border-bottom">
						<h2>Category List</h2>
					</div>
					    <table class="table">
							<thead>
								<tr>
									<th scope="col">#</th>
									<th scope="col">Category Name</th>
									<th scope="col">Action</th>
								</tr>
							</thead>
							<tbody>
								<tr style="color:#000">
									<td scope="row">1</td>
									<td>Lucia</td>
									<td>Christ</td>
								</tr>
							</tbody>
					    </table>
			    </div>
		    </div>
</div>
		
<?php $__env->stopSection(); ?>
          


       
<?php echo $__env->make('backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\ecom\resources\views/backend/category/categorylist.blade.php ENDPATH**/ ?>