<?php $__env->startSection('content'); ?>
          <div class="content">	
		  <a class="btn btn-info" href="<?php echo e(url('category')); ?>">Category List</a>
		  <div class="row">
				<div class="col-md-10">
					<div class="card card-default">
						<div class="card-header card-header-border-bottom">
							<h2>Add New Category</h2>
						</div>
						<div class="card-body">
							<form class="pl-5 pr-5" method="POST" action="<?php echo e(route('category.store')); ?>">
								<?php echo csrf_field(); ?>
								<div class="form-row">
									<div class="col-md-12 mb-3">
										<label for="validationServer01">Category name</label>
										<input type="text" class="form-control" name="category" id="validationServer01" placeholder="category name"  required>
										<div class="valid-feedback">
											Looks good!
										</div>
									</div>
								</div>
								<button class="btn btn-primary" type="submit">Save</button>
							</form>
						</div>
					</div>
				</div>
				</div>
		</div>
<?php $__env->stopSection(); ?>
          


       
<?php echo $__env->make('backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/backend/category/category.blade.php ENDPATH**/ ?>