<?php $__env->startSection('content'); ?>
<div class="content">							
  <div class="row">
		<div class="col-lg-12">
			<?php if(session()->has('msg')): ?>
				<div class="alert alert-success alert-dismissible fade show">
				   <?php echo e(session()->get('msg')); ?>


				   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
				</div>
			<?php endif; ?>
			<div class="card-header card-header-border-bottom">
				<a href=" <?php echo e(route('category.create')); ?>" class="btn btn-info float-right">Add Category</a>
				<h2>Category List</h2>
			</div>
			<br>
		    <table class="table">
				<thead>
					<tr>
						<th scope="col">#</th>
						<th scope="col">Category Name</th>
						<th scope="col">Description</th>
						<th scope="col">Action</th>
					</tr>
				</thead>
				<tbody>
					<?php if($categories): ?>
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr style="color:#000">
								<td scope="row"><?php echo e($i + 1); ?></td>
								<td><?php echo e($category->name); ?></td>
								<td><?php echo e($category->description); ?></td>
								<td>
									<a href="<?php echo e(route('category.edit',$category->id)); ?>" class="btn btn-info">Edit</a> ||
								    Delete
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</tbody>
		    </table>
		</div>
	</div>
</div>
		
<?php $__env->stopSection(); ?>
          


       
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\ecom\resources\views/layouts/backend/category/index.blade.php ENDPATH**/ ?>