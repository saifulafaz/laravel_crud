<?php $__env->startSection('content'); ?>
          <div class="content">							
		  <div class="row">
				<div class="col-lg-10"
									<div class="card card-default">
										<div class="card-header card-header-border-bottom">
											<h2>Category List</h2>
										</div>
										<div class="card-body">
											<table class="table">
												<thead>
													<tr>
														<th scope="col">#</th>
														<th scope="col">Category Name</th>
														<th scope="col">Action</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td scope="row">1</td>
														<td>Lucia</td>
														<td>Christ</td>
													</tr>
													<tr>
														<td scope="row">2</td>
														<td>Catrin</td>
														<td>Seidl</td>
													</tr>
													<tr>
														<td scope="row">3</td>
														<td>Lilli</td>
														<td>Kirsh</td>
													</tr>
													<tr>
														<td scope="row">4</td>
														<td>Else</td>
														<td>Voigt</td>
													</tr>
													<tr>
														<td scope="row">5</td>
														<td>Ursel</td>
														<td>Harms</td>
													</tr>
													<tr>
														<td scope="row">6</td>
														<td>Anke</td>
														<td>Sauter</td>
													</tr>
												</tbody>
											</table>
										
									</div>
								</div>
				</div>
				</div>
		</div>
<?php $__env->stopSection(); ?>
          


       
<?php echo $__env->make('backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/backend/category/categorylist.blade.php ENDPATH**/ ?>